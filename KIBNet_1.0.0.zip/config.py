# -*- coding: utf-8 -*-
# author: ZMgoog
# version: 1.0.0

__all__ = ['username', 'password', 'listen_interval', 'listen', 'exit_time']

# str, 用户名
username = 'xxx'

# str, 密码
password = 'xxx'

# int, 监听周期，即经过多少秒测试一次网络通畅情况。默认 5 秒
listen_interval = 5

# bool 是否启用启用监听模式 True/False
listen = True

# bool/ str 自定义监听时长(默认 False，即不会自动退出软件；'72:00:00' 表示 72h 后下线并退出软件。注意：listen = True 模式下该选项才有效)
exit_time = False
# exit_time = '72:00:00'
